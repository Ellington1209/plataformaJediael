<?php

namespace App\Http\Controllers\Nfse\Eusebio;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EnvioLoteController extends Controller
{
    public function envioLote(Request $request)
    {
        // Obtenha os dados do request
        $data = $request->all();

        // Construir o cabeçalho e os parâmetros como strings escapadas
        $header = '&lt;?xml version="1.0" encoding="UTF-8"?&gt;&lt;p:cabecalho versao="1" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:p="http://ws.speedgov.com.br/cabecalho_v1.xsd" xmlns:p1="http://ws.speedgov.com.br/tipos_v1.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://ws.speedgov.com.br/cabecalho_v1.xsd cabecalho_v1.xsd"&gt;&lt;versaoDados&gt;1&lt;/versaoDados&gt;&lt;/p:cabecalho&gt;';

        $parameters = '&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;p:EnviarLoteRpsEnvio xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:p="http://ws.speedgov.com.br/enviar_lote_rps_envio_v1.xsd" xmlns:p1="http://ws.speedgov.com.br/tipos_v1.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://ws.speedgov.com.br/enviar_lote_rps_envio_v1.xsd enviar_lote_rps_envio_v1.xsd"&gt;
&lt;p:LoteRps Id="' . $data['LoteRpsId'] . '"&gt;
&lt;p1:NumeroLote&gt;' . $data['NumeroLote'] . '&lt;/p1:NumeroLote&gt;
&lt;p1:Cnpj&gt;' . $data['Cnpj'] . '&lt;/p1:Cnpj&gt;
&lt;p1:InscricaoMunicipal&gt;' . $data['InscricaoMunicipal'] . '&lt;/p1:InscricaoMunicipal&gt;
&lt;p1:QuantidadeRps&gt;' . $data['QuantidadeRps'] . '&lt;/p1:QuantidadeRps&gt;
&lt;p1:ListaRps&gt;
&lt;p1:Rps&gt;
&lt;p1:InfRps Id=""&gt;
&lt;p1:IdentificacaoRps&gt;
&lt;p1:Numero&gt;' . $data['NumeroRps'] . '&lt;/p1:Numero&gt;
&lt;p1:Serie&gt;' . $data['SerieRps'] . '&lt;/p1:Serie&gt;
&lt;p1:Tipo&gt;' . $data['TipoRps'] . '&lt;/p1:Tipo&gt;
&lt;/p1:IdentificacaoRps&gt;
&lt;p1:DataEmissao&gt;' . $data['DataEmissao'] . '&lt;/p1:DataEmissao&gt;
&lt;p1:NaturezaOperacao&gt;' . $data['NaturezaOperacao'] . '&lt;/p1:NaturezaOperacao&gt;
&lt;p1:OptanteSimplesNacional&gt;' . $data['OptanteSimplesNacional'] . '&lt;/p1:OptanteSimplesNacional&gt;
&lt;p1:IncentivadorCultural&gt;' . $data['IncentivadorCultural'] . '&lt;/p1:IncentivadorCultural&gt;
&lt;p1:Status&gt;' . $data['StatusRps'] . '&lt;/p1:Status&gt;
&lt;p1:Servico&gt;
&lt;p1:Valores&gt;
&lt;p1:ValorServicos&gt;' . $data['ValorServicos'] . '&lt;/p1:ValorServicos&gt;
&lt;p1:ValorDeducoes&gt;' . $data['ValorDeducoes'] . '&lt;/p1:ValorDeducoes&gt;
&lt;p1:ValorPis&gt;' . $data['ValorPis'] . '&lt;/p1:ValorPis&gt;
&lt;p1:ValorCofins&gt;' . $data['ValorCofins'] . '&lt;/p1:ValorCofins&gt;
&lt;p1:ValorInss&gt;' . $data['ValorInss'] . '&lt;/p1:ValorInss&gt;
&lt;p1:ValorIr&gt;' . $data['ValorIr'] . '&lt;/p1:ValorIr&gt;
&lt;p1:ValorCsll&gt;' . $data['ValorCsll'] . '&lt;/p1:ValorCsll&gt;
&lt;p1:IssRetido&gt;' . $data['IssRetido'] . '&lt;/p1:IssRetido&gt;
&lt;p1:ValorIss&gt;' . $data['ValorIss'] . '&lt;/p1:ValorIss&gt;
&lt;p1:ValorIssRetido&gt;' . $data['ValorIssRetido'] . '&lt;/p1:ValorIssRetido&gt;
&lt;p1:OutrasRetencoes&gt;' . $data['OutrasRetencoes'] . '&lt;/p1:OutrasRetencoes&gt;
&lt;p1:BaseCalculo&gt;' . $data['BaseCalculo'] . '&lt;/p1:BaseCalculo&gt;
&lt;p1:Aliquota&gt;' . $data['Aliquota'] . '&lt;/p1:Aliquota&gt;
&lt;p1:ValorLiquidoNfse&gt;' . $data['ValorLiquidoNfse'] . '&lt;/p1:ValorLiquidoNfse&gt;
&lt;p1:DescontoCondicionado&gt;' . $data['DescontoCondicionado'] . '&lt;/p1:DescontoCondicionado&gt;
&lt;p1:DescontoIncondicionado&gt;' . $data['DescontoIncondicionado'] . '&lt;/p1:DescontoIncondicionado&gt;
&lt;/p1:Valores&gt;
&lt;p1:ItemListaServico&gt;' . $data['ItemListaServico'] . '&lt;/p1:ItemListaServico&gt;
&lt;p1:CodigoCnae&gt;' . $data['CodigoCnae'] . '&lt;/p1:CodigoCnae&gt;
&lt;p1:CodigoTributacaoMunicipio&gt;' . $data['CodigoTributacaoMunicipio'] . '&lt;/p1:CodigoTributacaoMunicipio&gt;
&lt;p1:Discriminacao&gt;' . $data['Discriminacao'] . '&lt;/p1:Discriminacao&gt;
&lt;p1:CodigoMunicipio&gt;' . $data['CodigoMunicipio'] . '&lt;/p1:CodigoMunicipio&gt;
&lt;/p1:Servico&gt;
&lt;p1:Prestador&gt;
&lt;p1:Cnpj&gt;' . $data['PrestadorCnpj'] . '&lt;/p1:Cnpj&gt;
&lt;p1:InscricaoMunicipal&gt;' . $data['PrestadorInscricaoMunicipal'] . '&lt;/p1:InscricaoMunicipal&gt;
&lt;/p1:Prestador&gt;
&lt;p1:Tomador&gt;
&lt;p1:IdentificacaoTomador&gt;
&lt;p1:CpfCnpj&gt;
&lt;p1:Cnpj&gt;' . $data['TomadorCnpj'] . '&lt;/p1:Cnpj&gt;
&lt;/p1:CpfCnpj&gt;
&lt;/p1:IdentificacaoTomador&gt;
&lt;p1:RazaoSocial&gt;' . $data['TomadorRazaoSocial'] . '&lt;/p1:RazaoSocial&gt;
&lt;p1:Endereco&gt;
&lt;p1:Endereco&gt;' . $data['TomadorEndereco'] . '&lt;/p1:Endereco&gt;
&lt;p1:Numero&gt;' . $data['TomadorNumero'] . '&lt;/p1:Numero&gt;
&lt;p1:Complemento&gt;' . $data['TomadorComplemento'] . '&lt;/p1:Complemento&gt;
&lt;p1:Bairro&gt;' . $data['TomadorBairro'] . '&lt;/p1:Bairro&gt;
&lt;p1:CodigoMunicipio&gt;' . $data['TomadorCodigoMunicipio'] . '&lt;/p1:CodigoMunicipio&gt;
&lt;p1:Uf&gt;' . $data['TomadorUf'] . '&lt;/p1:Uf&gt;
&lt;p1:Cep&gt;' . $data['TomadorCep'] . '&lt;/p1:Cep&gt;
&lt;/p1:Endereco&gt;
&lt;p1:Contato&gt;
&lt;p1:Telefone&gt;' . $data['TomadorTelefone'] . '&lt;/p1:Telefone&gt;
&lt;p1:Email&gt;' . $data['TomadorEmail'] . '&lt;/p1:Email&gt;
&lt;/p1:Contato&gt;
&lt;/p1:Tomador&gt;
&lt;/p1:InfRps&gt;
&lt;/p1:Rps&gt;
&lt;/p1:ListaRps&gt;
&lt;/p:LoteRps&gt;
&lt;/p:EnviarLoteRpsEnvio&gt;';

        // Construa o XML dinamicamente usando os dados recebidos
        $xml_string = '
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:nfse="http://www.abrasf.org.br/ABRASF/arquivos/nfse.xsd">
            <soapenv:Header/>
            <soapenv:Body>
                <nfse:RecepcionarLoteRps>
                    <header>' . $header . '</header>
                    <parameters>' . $parameters . '</parameters>
                </nfse:RecepcionarLoteRps>
            </soapenv:Body>
        </soapenv:Envelope>';

        // URL do servidor SOAP
        $url = 'http://speedgov.com.br/wsmod/Nfes?wsdl';

        // Inicializa o cURL
        $ch = curl_init($url);

        // Configura as opções do cURL
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Executa a requisição
        $response = curl_exec($ch);

        // Fecha o cURL
        curl_close($ch);

        // Retorna a resposta como JSON
        return response()->json(['response' => $response]);
    }
}
